from .session import get_session, AioSession

__all__ = ['get_session', 'AioSession']
__version__ = '1.2.2'
